% read image and convert to double
im = double(imread('lena.pgm'));

% run diffusion process
iterations = 500;
[result, video] = diffusion_filter(im, 'pm1', iterations, 10, 0.2);

% show result
imshow(uint8(result));

% write video to avi file
v = VideoWriter('diffusion.avi', 'Uncompressed AVI');
open(v);
for i=1:size(video,3)
    writeVideo(v, uint8(video(:,:,i)));
end
close(v);

